const mongoose = require('mongoose');
const billSchema = new mongoose.Schema({
  patientId: { type: String, required: true, trim: true },
  description: { type: String, required: true, trim: true },
  amount: { type: Number, required: true, min: 0.01 },
  billDate: { type: Date, required: true },
  paymentStatus: { type: String, enum: ['Unpaid','Paid'], default: 'Unpaid' },
  paymentMethod: { type: String, enum: ['','Cash','Card','Bank Transfer','Other'], default: '' }
}, { timestamps: true });
module.exports = mongoose.model('Bill', billSchema);
