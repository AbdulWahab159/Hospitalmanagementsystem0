# HMS-Billing-Backend

Patient bills, payment status, payment methods and unpaid totals.

## Requirements
- Node.js 18+
- MongoDB local instance or MongoDB Atlas

## Setup
```bash
npm install
cp .env.example .env
# Update MONGODB_URI in .env
npm run dev
```

Service runs on `http://localhost:5004`. Health check: `GET /health`.

## API base
`/api/bills`

## Endpoints
- `POST /api/bills` — create
- `GET /api/bills` — list (filters are documented below)
- `GET /api/bills/:id` — get one
- `PATCH /api/bills/:id` — update
- `DELETE /api/bills/:id` — delete

- `PATCH /api/bills/:id/pay` with JSON `{ "paymentMethod": "Cash" }` — mark paid
- `GET /api/bills/summary/unpaid` — total unpaid amount and count
- Filters: `GET /api/bills?patientId=...&paymentStatus=Unpaid`

Bill fields: `patientId`, `description`, `amount` (> 0), `billDate`, `paymentStatus`, `paymentMethod`.

## Example request
Use JSON request bodies and `Content-Type: application/json`.

## Notes
- Each repository is an independent service with its own MongoDB database.
- `patientId` and `doctorId` in other services are references stored as strings; they are not MongoDB cross-database foreign keys. Validate referenced IDs through the owning service in a production deployment.
- Add authentication/authorization and audit logging before using with real patient data. Do not commit `.env` or real patient information.
