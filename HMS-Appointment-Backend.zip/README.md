# HMS-Appointment-Backend

Appointment scheduling and status tracking.

## Requirements
- Node.js 18+
- MongoDB local instance or MongoDB Atlas

## Setup
```bash
npm install
cp .env.example .env
# Update MONGODB_URI in .env
npm run dev
```

Service runs on `http://localhost:5003`. Health check: `GET /health`.

## API base
`/api/appointments`

## Endpoints
- `POST /api/appointments` — create
- `GET /api/appointments` — list (filters are documented below)
- `GET /api/appointments/:id` — get one
- `PATCH /api/appointments/:id` — update
- `DELETE /api/appointments/:id` — delete

Filters: `GET /api/appointments?patientId=...&doctorId=...&status=Scheduled&from=2026-01-01&to=2026-01-31`.

Appointment fields: `patientId`, `doctorId`, `appointmentDate` (required), `reason`, `status`, `notes`. IDs are stored as strings because each service owns its own database. The exact-time doctor conflict check is not a substitute for a full availability/overlap scheduler.

## Example request
Use JSON request bodies and `Content-Type: application/json`.

## Notes
- Each repository is an independent service with its own MongoDB database.
- `patientId` and `doctorId` in other services are references stored as strings; they are not MongoDB cross-database foreign keys. Validate referenced IDs through the owning service in a production deployment.
- Add authentication/authorization and audit logging before using with real patient data. Do not commit `.env` or real patient information.
