const mongoose = require('mongoose');
const appointmentSchema = new mongoose.Schema({
  patientId: { type: String, required: true, trim: true },
  doctorId: { type: String, required: true, trim: true },
  appointmentDate: { type: Date, required: true },
  reason: { type: String, trim: true, default: '' },
  status: { type: String, enum: ['Scheduled','Confirmed','Completed','Cancelled'], default: 'Scheduled' },
  notes: { type: String, trim: true, default: '' }
}, { timestamps: true });
appointmentSchema.index({ doctorId: 1, appointmentDate: 1 });
module.exports = mongoose.model('Appointment', appointmentSchema);
