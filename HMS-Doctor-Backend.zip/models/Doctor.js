const mongoose = require('mongoose');
const doctorSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  specialty: { type: String, required: true, trim: true },
  phone: { type: String, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  qualification: { type: String, trim: true },
  consultationFee: { type: Number, min: 0, default: 0 },
  availability: [{ day: { type: String }, startTime: { type: String }, endTime: { type: String } }],
  active: { type: Boolean, default: true }
}, { timestamps: true });
module.exports = mongoose.model('Doctor', doctorSchema);
