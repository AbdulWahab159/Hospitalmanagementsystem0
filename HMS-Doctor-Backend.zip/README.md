# HMS-Doctor-Backend

Doctor profiles, specialties, availability and status.

## Requirements
- Node.js 18+
- MongoDB local instance or MongoDB Atlas

## Setup
```bash
npm install
cp .env.example .env
# Update MONGODB_URI in .env
npm run dev
```

Service runs on `http://localhost:5002`. Health check: `GET /health`.

## API base
`/api/doctors`

## Endpoints
- `POST /api/doctors` — create
- `GET /api/doctors` — list (filters are documented below)
- `GET /api/doctors/:id` — get one
- `PATCH /api/doctors/:id` — update
- `DELETE /api/doctors/:id` — delete

Filters: `GET /api/doctors?specialty=cardiology&active=true`.

Doctor fields: `name`, `specialty`, `email` (required), `phone`, `qualification`, `consultationFee`, `availability`, `active`.

## Example request
Use JSON request bodies and `Content-Type: application/json`.

## Notes
- Each repository is an independent service with its own MongoDB database.
- `patientId` and `doctorId` in other services are references stored as strings; they are not MongoDB cross-database foreign keys. Validate referenced IDs through the owning service in a production deployment.
- Add authentication/authorization and audit logging before using with real patient data. Do not commit `.env` or real patient information.
