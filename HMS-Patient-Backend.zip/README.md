# HMS-Patient-Backend

Patient registration, profile management, and medical records.

## Requirements
- Node.js 18+
- MongoDB local instance or MongoDB Atlas

## Setup
```bash
npm install
cp .env.example .env
# Update MONGODB_URI in .env
npm run dev
```

Service runs on `http://localhost:5001`. Health check: `GET /health`.

## API base
`/api/patients`

## Endpoints
- `POST /api/patients` — create
- `GET /api/patients` — list (filters are documented below)
- `GET /api/patients/:id` — get one
- `PATCH /api/patients/:id` — update
- `DELETE /api/patients/:id` — delete

### Medical records
- `POST /api/patients/:id/medical-records` — add a record (`diagnosis`, `treatment`, `prescription`, `recordDate`; optional `notes`)
- `GET /api/patients/:id/medical-records` — list records for a patient
- `GET /api/patients?search=ali&page=1&limit=20` — search and paginate patients

Patient fields: `name` (required), `age`, `gender`, `phone`, `email`, `address`, `bloodGroup`.

## Example request
Use JSON request bodies and `Content-Type: application/json`.

## Notes
- Each repository is an independent service with its own MongoDB database.
- `patientId` and `doctorId` in other services are references stored as strings; they are not MongoDB cross-database foreign keys. Validate referenced IDs through the owning service in a production deployment.
- Add authentication/authorization and audit logging before using with real patient data. Do not commit `.env` or real patient information.
