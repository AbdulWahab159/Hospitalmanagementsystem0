const mongoose = require('mongoose');
const medicalRecordSchema = new mongoose.Schema({
  diagnosis: { type: String, required: true, trim: true },
  treatment: { type: String, required: true, trim: true },
  prescription: { type: String, required: true, trim: true },
  recordDate: { type: Date, required: true },
  notes: { type: String, default: '', trim: true }
}, { timestamps: true });
const patientSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  age: { type: Number, min: 0, max: 130 },
  gender: { type: String, enum: ['Male', 'Female', 'Other'] },
  phone: { type: String, trim: true },
  email: { type: String, lowercase: true, trim: true },
  address: { type: String, trim: true },
  bloodGroup: { type: String, trim: true },
  medicalRecords: [medicalRecordSchema]
}, { timestamps: true });
module.exports = mongoose.model('Patient', patientSchema);
