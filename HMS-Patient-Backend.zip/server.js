const express = require('express');
const mongoose = require('mongoose');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
require('dotenv').config();
const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : true }));
app.use(express.json({ limit: '1mb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 200, standardHeaders: 'draft-7', legacyHeaders: false }));
app.get('/health', (req,res) => res.json({ service: process.env.SERVICE_NAME, status: 'ok' }));
app.use('/api/patients', require('./routes/patients'));
app.use((req,res) => res.status(404).json({ message: 'Route not found' }));
app.use((err,req,res,next) => {
  console.error(err);
  if (err.name === 'ValidationError') return res.status(400).json({ message: err.message });
  if (err.name === 'CastError') return res.status(400).json({ message: 'Invalid ID format' });
  if (err.code === 11000) return res.status(409).json({ message: 'A record with this value already exists' });
  res.status(500).json({ message: 'Internal server error' });
});
const PORT = process.env.PORT || 5001;
mongoose.connect(process.env.MONGODB_URI)
  .then(() => { console.log('MongoDB connected'); app.listen(PORT, () => console.log(`${process.env.SERVICE_NAME} listening on ${PORT}`)); })
  .catch(err => { console.error('MongoDB connection failed:', err.message); process.exit(1); });
